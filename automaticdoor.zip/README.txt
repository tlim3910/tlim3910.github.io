A Pen created at CodePen.io. You can find this one at https://codepen.io/tlim3910/pen/ZZOLOK.

 